#!/usr/bin/env ruby -wKU

require 'rubygems'
require 'xml'

dtd = XML::Dtd.new('-//Books', 'books.dtd')
doc = XML::Document.file('books-doctype.xml')

print "#{doc.validate(dtd)}\n"